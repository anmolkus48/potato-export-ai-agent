# Potato Export AI Agent — Ready Starter

This is a starter MVP for the potato export workflow (Agra, India → Birgunj, Nepal).

## Easiest Windows launch
1. Install Python 3.10+ from the official Python website if it is not already installed. During installation, tick **Add Python to PATH**.
2. Extract this ZIP to a folder.
3. Double-click `START_APP.bat`.
4. A terminal will install the required packages and launch the dashboard in your browser.

If Windows says Python is not found, install Python from https://www.python.org/downloads/windows/ and try again.

## Current functionality
- Buyer and supplier lead registers
- Quote register
- Indicative landed-cost calculator
- Email draft generator (draft only)

## Not yet connected
This package is not yet deployed online and has no Gmail connection. It does not send emails, make calls, place orders, or make payments. Do not enter passwords, OTPs, recovery codes, or bank details into the app.

## For online deployment
A hosting account and repository authorization are required. I cannot sign in using your password or bypass account authorization. If you share screenshots while you operate the account yourself, I can guide you through the steps. Use private repositories and do not upload confidential business data or credentials.
