@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo Potato Export AI Agent - Local Starter
echo ============================================
where py >nul 2>nul
if %errorlevel%==0 (
  set PY=py
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    set PY=python
  ) else (
    echo Python was not found.
    echo Please install Python 3.10 or newer from:
    echo https://www.python.org/downloads/windows/
    echo During installation, tick "Add Python to PATH".
    pause
    exit /b 1
  )
)
echo Installing required packages. This may take a few minutes...
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt
if %errorlevel% neq 0 (
  echo Package installation failed. Check internet connection and Python installation.
  pause
  exit /b 1
)
echo Starting dashboard...
%PY% -m streamlit run app/app.py
pause
