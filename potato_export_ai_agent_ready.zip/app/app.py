import streamlit as st
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)
FILES = {
 "buyers": DATA/"buyers.csv", "suppliers": DATA/"suppliers.csv",
 "quotes": DATA/"quotes.csv", "followups": DATA/"followups.csv", "costs": DATA/"costs.csv"
}
COLUMNS = {
 "buyers":["company","country","city","contact_name","email","phone","product_interest","estimated_quantity_kg","status","last_contact","next_followup","source","verification_notes"],
 "suppliers":["company","city","contact_name","email","phone","potato_type","quoted_price_inr_per_kg","available_quantity_kg","status","source","verification_notes"],
 "quotes":["date","counterparty_type","company","product","quantity_kg","price_per_kg","currency","incoterm","valid_until","notes"],
 "followups":["date","company","direction","subject","status","next_action","notes"],
 "costs":["item","amount_inr","basis","notes"]
}
def load(key):
    if not FILES[key].exists(): pd.DataFrame(columns=COLUMNS[key]).to_csv(FILES[key],index=False)
    return pd.read_csv(FILES[key]).fillna("")
for k in FILES: load(k)

st.set_page_config(page_title="Potato Export AI Agent",page_icon="🥔",layout="wide")
st.title("🥔 Potato Export AI Agent — MVP")
st.caption("Agra, India → Birgunj, Nepal | Leads, quotes, cost estimates and email drafts")
st.warning("MVP only: does not send emails, call buyers, place orders or make payments. Verify all leads, prices, freight and current import/export requirements.")
tabs=st.tabs(["Dashboard","Buyer Leads","Supplier Leads","Quotes","Landed Cost","Email Drafts","Guide"])
with tabs[0]:
    b,s,q,f=load("buyers"),load("suppliers"),load("quotes"),load("followups")
    a,c,d,e=st.columns(4)
    a.metric("Buyer leads",len(b)); c.metric("Supplier leads",len(s)); d.metric("Quotes",len(q)); e.metric("Follow-ups",len(f))
    st.subheader("Before buying stock")
    st.markdown("- Get written buyer requirements or PO.\n- Obtain supplier, freight and handling quotes.\n- Confirm Nepal import/plant-quarantine/customs rules with competent authorities and a customs broker.\n- Verify buyer identity and payment terms.\n- Calculate all costs and margin.\n- Obtain owner approval before binding offers, orders or payments.")
with tabs[1]:
    df=load("buyers"); edited=st.data_editor(df,num_rows="dynamic",use_container_width=True,key="buyers")
    if st.button("Save buyer leads"): edited.to_csv(FILES["buyers"],index=False); st.success("Saved.")
    st.download_button("Download CSV",df.to_csv(index=False).encode(),"buyers.csv")
with tabs[2]:
    df=load("suppliers"); edited=st.data_editor(df,num_rows="dynamic",use_container_width=True,key="suppliers")
    if st.button("Save supplier leads"): edited.to_csv(FILES["suppliers"],index=False); st.success("Saved.")
    st.download_button("Download CSV",df.to_csv(index=False).encode(),"suppliers.csv")
with tabs[3]:
    df=load("quotes"); edited=st.data_editor(df,num_rows="dynamic",use_container_width=True,key="quotes")
    if st.button("Save quotations"): edited.to_csv(FILES["quotes"],index=False); st.success("Saved.")
    st.download_button("Download CSV",df.to_csv(index=False).encode(),"quotes.csv")
with tabs[4]:
    st.subheader("Landed-cost planning calculator")
    qty=st.number_input("Quantity (kg)",min_value=1,value=1000,step=100)
    buy=st.number_input("Supplier price (₹/kg)",min_value=0.0,value=0.0,step=0.5)
    pack=st.number_input("Packing/loading total (₹)",min_value=0.0,value=0.0,step=500.0)
    freight=st.number_input("Freight total (₹)",min_value=0.0,value=0.0,step=1000.0)
    docs=st.number_input("India-side docs/handling (₹)",min_value=0.0,value=0.0,step=500.0)
    border=st.number_input("Border/Nepal-side handling/delivery (₹)",min_value=0.0,value=0.0,step=500.0)
    other=st.number_input("Insurance, spoilage reserve, other costs (₹)",min_value=0.0,value=0.0,step=500.0)
    sell=st.number_input("Buyer selling price (₹ equivalent/kg)",min_value=0.0,value=0.0,step=0.5)
    cost=qty*buy+pack+freight+docs+border+other; revenue=qty*sell; profit=revenue-cost; margin=profit/revenue*100 if revenue else 0
    x,y,z,w=st.columns(4); x.metric("Total cost",f"₹{cost:,.2f}"); y.metric("Cost/kg",f"₹{cost/qty:,.2f}"); z.metric("Estimated gross profit",f"₹{profit:,.2f}"); w.metric("Gross margin",f"{margin:.2f}%")
    st.error("Planning estimate only. Add verified duties/taxes, inspection/quarantine fees, broker charges, currency effects, financing and buyer-specific costs before relying on this.")
    if st.button("Save cost scenario"):
        old=load("costs")
        pd.concat([old,pd.DataFrame([{"item":"scenario","amount_inr":round(cost,2),"basis":f"{qty} kg; buy ₹{buy}/kg; sell ₹{sell}/kg; profit ₹{profit:.2f}; margin {margin:.2f}%","notes":"User-entered estimate; not verified"}])],ignore_index=True).to_csv(FILES["costs"],index=False)
        st.success("Scenario saved.")
with tabs[5]:
    typ=st.selectbox("Draft type",["Buyer introduction","Buyer requirement enquiry","Supplier RFQ","Follow-up"])
    company=st.text_input("Recipient company")
    contact=st.text_input("Contact name (optional)")
    product=st.text_input("Product / grade","Fresh potatoes")
    qtytxt=st.text_input("Quantity","Please advise your required quantity")
    delivery=st.text_input("Delivery / terms","Birgunj, Nepal; terms to be agreed")
    sender=st.text_input("Your name / business","Anmol Singh")
    if st.button("Generate draft"):
        greeting=f"Dear {contact}," if contact.strip() else "Dear Team,"
        if typ=="Buyer introduction":
            subject="Supply Enquiry – Fresh Potatoes from Agra, India"
            body=f"""{greeting}

We are exploring supply opportunities for {product} sourced from Agra, India, for delivery to {delivery}.

Could you share your current requirement, preferred grade/size, packing, quantity ({qtytxt}), required documents/permits, delivery terms and payment terms?

Any offer will be subject to supplier, logistics and applicable import/export requirement checks.

Regards,
{sender}"""
        elif typ=="Buyer requirement enquiry":
            subject="Request for Current Potato Requirement and Specifications"
            body=f"""{greeting}

Please share your current requirement for {product}, including grade/size, quantity ({qtytxt}), packing, delivery location ({delivery}), required documents/permits, target price and payment terms.

Regards,
{sender}"""
        elif typ=="Supplier RFQ":
            subject="Request for Quotation – Fresh Potatoes"
            body=f"""{greeting}

Please quote your best price for {product} from Agra, India. Confirm available quantity ({qtytxt}), grade/size, packing, loading point, price validity, quality documents and experience supplying Nepal.

This is an enquiry, not a purchase order. Any purchase requires written approval after cost and compliance checks.

Regards,
{sender}"""
        else:
            subject="Follow-up on Potato Supply Enquiry"
            body=f"""{greeting}

I am following up on our earlier enquiry regarding {product}. Please share an update on availability, quantity ({qtytxt}), specifications, price validity and terms for {delivery}.

Regards,
{sender}"""
        st.text_input("Subject",subject,key="subj")
        st.text_area("Email body",body,height=240,key="body")
        st.info("Draft only. Review and send manually; no email has been sent.")
with tabs[6]:
    st.markdown("""### Getting started
1. Add buyer and supplier leads in their tabs.
2. Record each quotation, including currency, quantity, grade, Incoterm and validity.
3. Use the cost calculator only with actual quotes.
4. Verify current Nepal import/plant-quarantine requirements with authorities/customs broker.
5. Keep final price commitments, orders and payments under your explicit approval.
6. Never store passwords, OTPs or recovery codes in this app.
""")
