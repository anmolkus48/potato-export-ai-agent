# Launch and business safety checklist

- Verify each buyer and supplier; directory listing does not prove active demand.
- Obtain written buyer requirements and supplier quotations.
- Confirm current Nepal import, customs, tax and plant-quarantine requirements with relevant authorities and a qualified customs broker.
- Obtain actual freight, border handling, inspection, packing, and spoilage cost estimates.
- Do not purchase stock based on an unconfirmed buyer lead.
- The agent must not commit final prices, place binding orders or make payments without the owner's explicit approval.
- Email integration should start in draft-only mode and require OAuth/official integration; never share Gmail password or OTP.
